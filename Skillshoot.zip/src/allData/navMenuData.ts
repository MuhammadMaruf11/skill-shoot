export const navMenuData = [
  {
    title: "Home",
    url: "/",
  },
  {
    title: "Course",
    url: "",
  },
  {
    title: "Subscribe",
    url: "",
  },
  {
    title: "About",
    url: "",
  },
  {
    title: "Testimoni",
    url: "",
  },
];
