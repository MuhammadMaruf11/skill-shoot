export const testimonialData = [
  {
    img: "/img/testimonial/profile-1.svg",
    rating: "5",
    name: "Jason Bay",
    comment: `I am quite satisfied, because the skills I want or dream of can really be mastered`,
  },
  {
    img: "/img/testimonial/profile-2.svg",
    rating: "4",
    name: "Nany Brugman",
    comment: `I am quite satisfied, because the skills I want or dream of can really be mastered`,
  },
  {
    img: "/img/testimonial/profile-3.svg",
    rating: "5",
    name: "Alexa Nowan",
    comment: `I am quite satisfied, because the skills I want or dream of can really be mastered`,
  },
  {
    img: "/img/testimonial/profile-1.svg",
    rating: "3",
    name: "Jason Bay",
    comment: `I am quite satisfied, because the skills I want or dream of can really be mastered`,
  },
  {
    img: "/img/testimonial/profile-2.svg",
    rating: "5",
    name: "Nany Brugman",
    comment: `I am quite satisfied, because the skills I want or dream of can really be mastered`,
  },
  {
    img: "/img/testimonial/profile-3.svg",
    rating: "2",
    name: "Alexa Nowan",
    comment: `I am quite satisfied, because the skills I want or dream of can really be mastered`,
  },
];
