export const letUsData = [
  {
    img: "/img/icons/icon-4.svg",
    title: "15K People Join",
  },
  {
    img: "/img/icons/icon-5.svg",
    title: "Trusted Mentor",
  },
  {
    img: "/img/icons/icon-6.svg",
    title: "30+ Free Videos",
  },
  {
    img: "/img/icons/icon-7.svg",
    title: "100+ Premium Videos",
  },
];
