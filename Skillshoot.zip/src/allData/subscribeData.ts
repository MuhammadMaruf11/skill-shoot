export const subscribeData = [
  {
    price: `50`,
    description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry.`,
    type: "Base",
    month: "1",
    url: "",
    list: [
      "Access all videos",
      "Get Certificate",
      "Chat support",
      "Update Notification",
      "Download material",
    ],
  },
  {
    price: `100`,
    description: `Lorem Ipsum is simply dummy text of the printing `,
    type: "Pro",
    month: "6",
    url: "",
    list: [
      "Access all videos",
      "Get Certificate",
      "Chat support",
      "Update Notification",
      "Download material",
    ],
  },
  {
    price: `200`,
    description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry.`,
    type: "Enterprise",
    month: "12",
    url: "",
    list: [
      "Access all videos",
      "Get Certificate",
      "Chat support",
      "Update Notification",
      "Download material",
    ],
  },
];
