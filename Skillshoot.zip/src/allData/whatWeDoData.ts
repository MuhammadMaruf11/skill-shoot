export const whatWeDoData = [
  {
    img: "/img/what-we-do/icon-1.svg",
    title: "Material Limitations",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
  },
  {
    img: "/img/what-we-do/icon-2.svg",
    title: "Unprofessional Mentor",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
  },
  {
    img: "/img/what-we-do/icon-3.svg",
    title: "Video Quality",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
  },
  {
    img: "/img/what-we-do/icon-4.svg",
    title: "High Price",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
  },
];
