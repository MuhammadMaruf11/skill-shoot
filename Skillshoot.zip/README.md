## Getting Started

First, install the development server:

```bash
npm i or npm i -f (if needed)
```

Second, run the development server:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Deploy on Netlify

This project deployed here [Netlify Project](https://skill-shoot-task.netlify.app/)
